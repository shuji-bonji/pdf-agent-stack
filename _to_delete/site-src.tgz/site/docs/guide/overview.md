---
description: The big picture of PDF Agent Stack — four MCP servers, three Skills, and why observation, judgment, creation and norms are kept apart
---

# What is PDF Agent Stack?

PDF Agent Stack is the collective name for four independent [MCP](/reference/glossary#base-vocabulary-of-this-site-ai-engineering) servers and three [Skills](/reference/glossary#base-vocabulary-of-this-site-ai-engineering) that give AI agents the ability to **read, verify, and write PDFs — grounded in the spec**.

## Components

| Kind | Name | Role | Distribution |
|---|---|---|---|
| MCP | [pdf-spec-mcp](/mcp/pdf-spec) | Consult the PDF specification (ISO 32000 and 16 more documents) | [npm](https://www.npmjs.com/package/@shuji-bonji/pdf-spec-mcp) · [GitHub](https://github.com/shuji-bonji/pdf-spec-mcp) |
| MCP | [pdf-reader-mcp](/mcp/pdf-reader) | Observe a PDF's internal state (20 observation tools) | [npm](https://www.npmjs.com/package/@shuji-bonji/pdf-reader-mcp) · [GitHub](https://github.com/shuji-bonji/pdf-reader-mcp) |
| MCP | [pdf-verify-mcp](/mcp/pdf-verify) | Verify authenticity and conformance (7 judgment tools) | [npm](https://www.npmjs.com/package/@shuji-bonji/pdf-verify-mcp) · [GitHub](https://github.com/shuji-bonji/pdf-verify-mcp) |
| MCP | [pdf-writer-mcp](/mcp/pdf-writer) | Generate PDFs following the spec (20 creation/editing tools) | [npm](https://www.npmjs.com/package/@shuji-bonji/pdf-writer-mcp) · [GitHub](https://github.com/shuji-bonji/pdf-writer-mcp) |
| Skill | [pdf-trust](/skills/pdf-trust) | Vet incoming PDFs and confirm trust (Trust Report) | [GitHub](https://github.com/shuji-bonji/pdf-trust-skill) |
| Skill | [pdf-publish](/skills/pdf-publish) | Generate through a quality-gated pipeline (Publish Report) | [GitHub](https://github.com/shuji-bonji/pdf-publish-skill) |
| Skill | [pdf-read](/skills/pdf-read) | Pull what you need out of large or unreadable PDFs (Read Report) | [GitHub](https://github.com/shuji-bonji/pdf-read-skill) |

Two libraries sit under the servers and are published on their own:

- [pdf-constraints](/reference/pdf-constraints) — the data library behind pdf-verify's clause checking, transcribing ISO 32000 clauses into machine-checkable constraint tables. Usable on its own, including as a CLI in CI
- [normativepdf](https://github.com/shuji-bonji/normativepdf) — the PDF library pdf-writer writes through, in which every behaviour is tied to an ISO 32000 clause

::: info On architecture and responsibilities
How these fit together and run — see [Architecture & Responsibilities](/guide/architecture) for the details. Why the stack reads structure through MCP instead of converting a PDF to Markdown is set against the PDF Association's FAQ in [What an AI Drops When It Reads a PDF](/guide/ai-and-pdf).
:::

An agent may call the MCPs directly, or leave the orchestration to a Skill. With the Skills installed, the **call order, how to read the verdicts, and the report format** are all fixed for you.

## Try it in 5 minutes

1. Set up pdf-reader following [Getting Started](/guide/getting-started)
2. Point it at a local PDF: "Show me this PDF's metadata and structure"
3. For a signed PDF, add pdf-verify: "Has this PDF been tampered with?"
4. Move on to real workflows in [Use Cases](/use-cases/)
